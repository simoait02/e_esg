import '../models/doctor.dart';

Doctor doctor1=Doctor("Dr. Suissi","assets/images/profiletele.jpg");
Doctor doctor2=Doctor("Dr. Chaimae Bouti","assets/images/profile.jpg");
Doctor doctor3=Doctor("Dr. Aithssaine Mohammed","assets/images/profiletele.png");
Doctor doctor4=Doctor("Dr. Yasmine Elmouddine","assets/images/profile.jpg");
Doctor doctor5=Doctor("Inf. Saida Hanafi","assets/images/profiletele.png");
Doctor doctor6=Doctor("Dr. Smissri","assets/images/profiletele.png");
Doctor doctor7=Doctor("Dr. Sanae","assets/images/profile.jpg");
Doctor doctor8=Doctor("Inf. Safae","assets/images/profile.jpg");
List<Doctor> doctorList = [
doctor1,
doctor2,
doctor3,
doctor4,
doctor5,
doctor6,
doctor7,
doctor8,
];