class Proposition{
  final String subject;
  final String userimage;
  bool checked;
  double proportion;

  Proposition(
      this.subject,
      this.userimage,
      this.checked,
      this.proportion
      );
}