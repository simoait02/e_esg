class Jeune {
  final String nom;
  final String prenom;
  final int age;
  final String sexe;
  final String numtele;

  Jeune(
      this.nom,
      this.prenom,
      this.age,
      this.sexe,
      this.numtele
      );

}