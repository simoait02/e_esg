class Doctor {
  final String name;
  final String profil;

  Doctor(this.name,this.profil);
}