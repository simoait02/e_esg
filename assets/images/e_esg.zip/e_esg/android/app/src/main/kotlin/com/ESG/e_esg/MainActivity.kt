package com.ESG.e_esg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
